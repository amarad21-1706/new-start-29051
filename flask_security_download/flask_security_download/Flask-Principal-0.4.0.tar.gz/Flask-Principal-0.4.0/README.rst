Flask-Principal
===============

.. image:: https://secure.travis-ci.org/mattupstate/flask-principal.png?branch=develop

Identity management for Flask applications. This extension was originally 
written by Ali Afshar. Thanks to him for his great work. This is the new and
official repository for this project.

Documentation: http://packages.python.org/Flask-Principal/